# decision-landscape

圆桌讨论的最终聚合层：把讨论状态与元认知报告整合成结构化的决策景观，包含共识区（带共识强度）、分歧区（带事实/价值/术语/伪分歧类型与消解路径）、隐性假设清单、决策建议（按高置信度/中等/需补充信息分级）、信息缺口清单，以及少数派观点保护。当用户要求汇总一场圆桌讨论的结论、需要决策报告、问「这些讨论最后得出什么」「哪些结论能用、哪些还缺信息」，或 roundtable-orchestrator 在讨论关闭后调用聚合层时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/decision-landscape/` |
| Cursor / Cline / Windsurf | 项目内 `skills/decision-landscape/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/decision-landscape/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

**如果你的宿主不支持 ZIP 导入**：克隆 GitHub 仓库后跑 `python tools/quickstart.py`，
30 秒即可。

---

## 里面有什么

```
decision-landscape/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── output-templates.md
├── scripts/
│   └── synthesis_generator.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

需要 Python 3.9+，仅用标准库，不需要安装任何依赖。

许可：MIT。
