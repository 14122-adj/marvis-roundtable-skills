# roundtable-orchestrator

多角色圆桌讨论的编排引擎：调度角色思维协议、元认知监督者与立场迭代，按目标驱动推进多轮讨论并产出决策景观素材。当用户要求组织多角色圆桌讨论、让不同视角就同一问题交叉论证，或说「开启圆桌讨论」「让几个角色辩一辩」「多视角会诊」「圆桌推演」「让马斯克/费曼/芒格/乔布斯/Karpathy/Paul Graham 一起讨论」时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/roundtable-orchestrator/` |
| Cursor / Cline / Windsurf | 项目内 `skills/roundtable-orchestrator/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/roundtable-orchestrator/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
roundtable-orchestrator/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── interaction-protocols.md
├── scripts/
│   └── convergence_detector.py
│   └── round_controller.py
│   └── state_manager.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
