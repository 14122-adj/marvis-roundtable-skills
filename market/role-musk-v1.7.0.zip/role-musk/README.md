# role-musk

以第一性原理拆解为硬约束的圆桌角色技能。当用户要求以马斯克式第一性原理视角参与多角色圆桌讨论、需要把问题拆到最底层事实再向上推理，或 roundtable-orchestrator 调用 musk 角色发言时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/role-musk/` |
| Cursor / Cline / Windsurf | 项目内 `skills/role-musk/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/role-musk/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

**如果你的宿主不支持 ZIP 导入**：克隆 GitHub 仓库后跑 `python tools/quickstart.py`，
30 秒即可。

---

## 里面有什么

```
role-musk/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── first-principles-examples.md
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

需要 Python 3.9+，仅用标准库，不需要安装任何依赖。

许可：MIT。
