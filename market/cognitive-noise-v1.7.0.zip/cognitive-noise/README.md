# cognitive-noise

轻量认知噪声层（默认关闭）：为圆桌角色注入三种可控的不完美——选择性注意（只看见部分历史并必须声明忽略了什么）、表达偏好（先说结论/先说顾虑/保守/冒险四档）、置信度传导（低置信度必须带保留语气，高置信度必须自陈可能错在哪）。当用户觉得讨论太干净太理性、要求模拟真人的表达质感与不确定性，或 roundtable-orchestrator 在 mode=simulation 下需要注入噪声时，必须使用本技能。仅在 simulation 模式下可用。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/cognitive-noise/` |
| Cursor / Cline / Windsurf | 项目内 `skills/cognitive-noise/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/cognitive-noise/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
cognitive-noise/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── cognitive-noise-guide.md
├── scripts/
│   └── noise_injector.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
