# host-bootstrap

跨 AI 宿主的技能自检与自动部署：检测当前运行在 Claude Code / Codex / Hermes / 马维斯 / 其他环境，校验六个角色技能（role-musk/feynman/munger/jobs/karpathy/pg）是否就绪，缺失时从本地仓库或 GitHub 自动补齐。当用户要求把圆桌技能接入别的 AI、换一个客户端使用、或某个角色技能报缺失/不生效时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/host-bootstrap/` |
| Cursor / Cline / Windsurf | 项目内 `skills/host-bootstrap/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/host-bootstrap/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
host-bootstrap/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── host-matrix.md
├── scripts/
│   └── bootstrap.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
