# multi-model-adapter

异构基座适配层：同一底座模型的认知偏见是共通的，本技能把每个角色编译成独立的调用包（提示骨架 + 上下文 + 输出契约 + 隔离要求），交给支持多 provider 的宿主分别执行，再把结果合回同一个讨论状态。当用户要求用不同模型跑同一个圆桌、担心多角色共享同一基座而盲区一致、需要跨模型交叉验证，或 roundtable-orchestrator 要把角色分发到不同模型时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/multi-model-adapter/` |
| Cursor / Cline / Windsurf | 项目内 `skills/multi-model-adapter/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/multi-model-adapter/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

**如果你的宿主不支持 ZIP 导入**：克隆 GitHub 仓库后跑 `python tools/quickstart.py`，
30 秒即可。

---

## 里面有什么

```
multi-model-adapter/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── provider-assignment-guide.md
├── scripts/
│   └── runtime_manifest.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

需要 Python 3.9+，仅用标准库，不需要安装任何依赖。

许可：MIT。
