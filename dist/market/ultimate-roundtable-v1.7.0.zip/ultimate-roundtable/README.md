# ultimate-roundtable

终极专家圆桌机制 V4.1：引入注意力分舱、语义级死锁检测强制收敛与颗粒度执行指标，从深度推演走向绝对落地的战术指挥部。当用户要求开启终极圆桌、深度推演讨论、红蓝对抗圆桌、战术推演圆桌，或需要在一场高冲突讨论后拿到带负责人/KPI/止损点的战术级行动清单时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/ultimate-roundtable/` |
| Cursor / Cline / Windsurf | 项目内 `skills/ultimate-roundtable/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/ultimate-roundtable/` |

装好后对它说：

> 用它开始一场终极圆桌讨论

---

## 里面有什么

```
ultimate-roundtable/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── adversarial-tactics.md
│   └── report-template.md
│   └── tactical-playbook.md
│   └── tool-protocol.md
├── scripts/
│   └── attention_split.py
│   └── clash_analyzer.py
│   └── deadlock_detector.py
│   └── memory_store.py
│   └── ultimate_orchestrator.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
