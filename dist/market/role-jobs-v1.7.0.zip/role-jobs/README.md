# role-jobs

以产品纯粹性追问为硬约束的圆桌角色技能：每个决策都要回答让事情更简单还是更复杂，拒绝把因为一直这样做当理由。当用户要求以乔布斯式产品视角参与圆桌讨论、需要做减法与体验倒推，或 roundtable-orchestrator 调用 jobs 角色发言时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/role-jobs/` |
| Cursor / Cline / Windsurf | 项目内 `skills/role-jobs/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/role-jobs/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
role-jobs/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── simplicity-criteria.md
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
