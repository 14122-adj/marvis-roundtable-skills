# meta-supervisor

圆桌讨论的元认知监督者：不参与议题站队，专门挖掘所有人共同默认却从未论证的隐性假设、区分事实/价值/术语/伪分歧、标记信息缺口、筛查逻辑谬误，并把结论作为下一轮的强制输入。当用户要求挖掘讨论的底层前提、复盘一场讨论的质量、问「我们是不是在争论伪问题」「这场讨论的根本分歧是什么」，或 roundtable-orchestrator 在每轮结束后调用元认知层时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/meta-supervisor/` |
| Cursor / Cline / Windsurf | 项目内 `skills/meta-supervisor/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/meta-supervisor/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
meta-supervisor/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── metacognitive-checklist.md
├── scripts/
│   └── assumption_extractor.py
│   └── divergence_classifier.py
│   └── fallacy_detector.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
