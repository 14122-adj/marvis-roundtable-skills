# position-evolution

圆桌讨论的立场演化机制：判定角色什么时候、以多大幅度修正自己的观点，记录 from/to/trigger，并阻止无新证据的从众漂移。当用户要求在讨论中允许角色被说服、需要记录某角色观点如何变化，或 roundtable-orchestrator 处理角色发言中的 revision 块、刷新下一轮立场基线时，必须使用本技能。

---

## 装法

把本目录整个放进你 AI 客户端的 skills 目录：

| 客户端 | 目标位置 |
|---|---|
| Claude Code | `~/.claude/skills/position-evolution/` |
| Cursor / Cline / Windsurf | 项目内 `skills/position-evolution/` |
| 马维斯 Marvis | 技能管理 → 导入技能 → 选本目录的 `SKILL.md` |
| 其他（读 AGENTS.md 的） | 放进 `skills/position-evolution/` |

装好后对它说：

> 让这个技能参与你的圆桌讨论

---

## 里面有什么

```
position-evolution/
├── SKILL.md          ← 技能本体（agent 读这个）
├── references/
│   └── revision-protocols.md
├── scripts/
│   └── revision_tracker.py
```

---

## 说明

本技能是圆桌讨论体系的一部分，单独使用也可以；配套技能见仓库 README。
脚本仅用 Python 标准库，不需要安装依赖。

许可：MIT。
