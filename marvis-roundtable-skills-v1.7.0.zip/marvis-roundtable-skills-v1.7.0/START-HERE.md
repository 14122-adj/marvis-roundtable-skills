# 从这里开始

> 你拿到的是 **marvis-roundtable-skills v1.7.0** 的完整包
> （14 个核心技能 + 2 个社区角色，构建于 2026-11-01T14:01:50）。

---

## 最快：先跑一次看看

```bash
python tools/quickstart.py
```

约 10 秒，你会看到：体检 → 跑完一场完整的终极圆桌 → 自检 → 下一步提示。
产物在 `.quickstart/`（`report.md` 就是一场完整的决策报告）。

**只想确认环境可用**：

```bash
python tools/quickstart.py --check
```

---

## 换成你自己的议题

```bash
python tools/wizard.py
```

交互式向导会问你几组问题，生成 5 个阶段的配置文件，**每步即时校验**。
生成完会直接打印可复制的命令序列。

详细路径（含三个常见卡点）：**[QUICKSTART.md](QUICKSTART.md)**

---

## 装进你的 AI 客户端

```bash
python skills/host-bootstrap/scripts/bootstrap.py detect    # 我在什么宿主？
python skills/host-bootstrap/scripts/bootstrap.py install   # 补齐缺失的角色技能
```

然后按宿主导入：

| 宿主 | 入口 |
|---|---|
| 马维斯 Marvis | 技能管理 → 本地技能 → 导入技能 → 选 `skills/*/SKILL.md` |
| Claude Code | 读 `CLAUDE.md`，或把 `skills/` 放进 `~/.claude/skills` |
| Codex / Hermes / Cursor | 读 `AGENTS.md`，或放进各自的 skills 目录 |
| 纯文本对话 | 把 `SKILL.md` 内容贴进上下文，工具结果标 `simulated: true` |

**导入顺序**见 `import-manifest.json` 的 `import_order` 字段：
先 `host-bootstrap` 与编排层，再六个角色，最后可选层。

---

## 包里有什么

```
START-HERE.md          ← 你正在读的
QUICKSTART.md          ← 10 分钟完整路径 + 三个常见卡点
README.md              ← 全貌（架构、路线图、诚实声明）
CONTRIBUTING.md        ← 怎么贡献一个新角色
skills/                ← 14 个核心技能（每个 = SKILL.md + scripts/ + references/）
community-roles/       ← 2 个社区角色 + 模板
templates/             ← 5 个可直接改的阶段配置示例
tools/                 ← quickstart / wizard / 自检 / 打包 / 端到端 demo
docs/output-contract.md ← 所有字段的唯一来源（改任何东西前先读它）
```

---

## 一句话

```bash
python tools/quickstart.py     # 看它长什么样（10 秒）
python tools/wizard.py         # 换成你的议题（5 分钟）
```

剩下都是细节。

---

许可：MIT。问题与建议请提 issue。
